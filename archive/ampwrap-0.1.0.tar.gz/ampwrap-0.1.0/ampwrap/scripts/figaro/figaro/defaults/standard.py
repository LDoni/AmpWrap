from .environment import *

minOverlap = 20
loggingLevel = "INFO"
subsample = -1
percentile = 83
forwardPrimerLength = 19
reversePrimerLength = 19
