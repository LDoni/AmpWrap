# Init file for ampwrap package
